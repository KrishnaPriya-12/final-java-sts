import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserLoginDTO } from './user';

interface AppUser {
  username:string;
  password:string;
  role:string;
  photo:string;

}

@Injectable({
  providedIn: 'root'
})
export class DataOperationService {
  baseURL = 'http://localhost:6001';
  loginURL : string = this.baseURL+'/customer/login/';
  addUserEndpoint=this.baseURL+'/customer/add';
  
  allAppUsers:AppUser[] = [];

  constructor(private http:HttpClient) {

    let user1: AppUser = {
    
      username: "priya",
      password: "123",
      role: "Customer",
      photo: "profile.jpg"
    }
    let user2: AppUser = {
      username: "sweetha",
      password: "123",
      role: "Customer",
      photo: "profile.jpg"
    }
    let user3: AppUser = {
      username: "bhagya",
      password: "123",
      role: "Customer",
      photo: "profile.jpg"
    }
    let user4: AppUser = {
      username: "keerthana",
      password: "123",
      role: "Customer",
      photo: "profile.jpg"
    }
    let user5: AppUser = {
      username: "yamini",
      password: "123",
      role: "Customer",
      photo: "profile.jpg"
    }
    let user6: AppUser = {
      username: "admin",
      password: "admin",
      role: "admin",
      photo: "profile.jpg"
    }

    this.allAppUsers = [user1, user2, user3, user4, user5, user6];


  }

  doSpringLogin(userId:string,password:string):Observable<UserLoginDTO>
  {
    let a:string = this.loginURL+userId+'/'+password;
    return this.http.get<UserLoginDTO>(`${a}`);
  
  
  }

  addUser(userLogin:UserLoginDTO):Observable<UserLoginDTO>
  {
    
    //this.orderArr.push(orderFromUser); 
    //console.log("Inside Product Service : Product Added "+orderFromUser.bookingOrderId);
    //console.log(" Total Products Are :- "+this.orderArr.length);
    console.log('user Service - Add user called ');
    return this.http.post<UserLoginDTO>(`${this.addUserEndpoint}`,userLogin);
    
  }

  doLogin(ipUsername: string, ipPassword: string):boolean{
    localStorage.removeItem('username')
    localStorage.removeItem('role')
    localStorage.removeItem('loginStatus')
    localStorage.removeItem('photo')



    console.log("inside Service : " + ipUsername + " & " + ipPassword);

    
for(let i=0;i<this.allAppUsers.length;i++)
{
   let thisUser:AppUser = this.allAppUsers[i];

   if(thisUser.username == ipUsername && thisUser.password == ipPassword)
   {
      
      localStorage.setItem("username",ipUsername);
      localStorage.setItem("role",thisUser.role);
      localStorage.setItem("loginStatus",true+'');
      localStorage.setItem("photo",thisUser.photo);

      console.log("inside service for true ");

      return true; // note the break is not applicable in forEach because of window property
   }

}



return false;
    
  } //end of doLogin

doUserLogout()
{
  localStorage.removeItem('customerId')
  localStorage.removeItem('username')
  localStorage.removeItem('role')
  localStorage.removeItem('loginStatus')
  localStorage.removeItem('photo')

  console.log("inside Service logout ");

}
}
