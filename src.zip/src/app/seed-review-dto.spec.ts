import { SeedReviewDto } from './seed-review-dto';

describe('SeedReviewDto', () => {
  it('should create an instance', () => {
    expect(new SeedReviewDto()).toBeTruthy();
  });
});
